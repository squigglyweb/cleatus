<?php
/*
Plugin Name: TLN Plugin Bundle
Description: Business profiles, directory, and member features for The Local NearBuy
Version: 2.6 - FULL DESIGN IN PLUGIN
*/

// Load other TLN components
require_once plugin_dir_path(__FILE__) . 'tln-directory.php';
require_once plugin_dir_path(__FILE__) . 'tln-claim.php';

// Profile page handler
if (!is_admin()) {
    add_filter('the_content', 'tln_profile_content');
}

function tln_profile_content($content) {
    if (!is_page('profile')) {
        return $content;
    }
    
    $biz = isset($_GET['biz']) ? $_GET['biz'] : '';
    $pid = isset($_GET['pid']) ? $_GET['pid'] : '';
    
    if (empty($biz) || empty($pid)) {
        return '<div style="padding:2rem;background:#f0f0f0;border-radius:8px;"><h3>TLN Profile</h3><p>Add ?biz=Name&pid=PlaceID to URL.</p></div>';
    }
    
    // Full profile HTML - directly in plugin
    $html = '
    <style>
    .tln-profile { max-width:900px; margin:0 auto; font-family:\'Open Sans\',sans-serif; }
    .tln-hero { 
        background: linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.6)),
        url(\'https://thelocalnearbuy.com/wp-content/uploads/2026/05/town-scene-bkgd-scaled.webp\');
        background-size:cover;background-position:center;height:280px;position:relative;
    }
    .tln-hero-content { position:absolute;bottom:1.5rem;left:1.5rem; }
    .tln-hero h1 { color:#fff;font-size:2.5rem;margin:0 0 0.5rem; }
    .tln-hero p { color:rgba(255,255,255,0.9);font-size:1.1rem;margin:0; }
    .tln-main { display:grid;grid-template-columns:300px 1fr;gap:2rem;padding:2rem;background:#fff;margin-top:-2rem;position:relative;border-radius:12px;box-shadow:0 4px12px rgba(0,0,0,0.1); }
    .tln-left { display:flex;flex-direction:column;gap:1.5rem; }
    .tln-right { display:flex;flex-direction:column;gap:1.5rem; }
    .tln-card { background:#fff;border:1px solid #ddd;border-radius:8px;padding:1.25rem; }
    .tln-card h3 { margin:0 0 1rem;font-size:1rem;color:#1a1a1a;border-bottom:1px solid #eee;padding-bottom:0.5rem; }
    .tln-label { font-weight:600;color:#1a1a1a;font-size:0.9rem; }
    .tln-value { color:#666;font-size:0.9rem; }
    .tln-hours-row { display:flex;justify-content:space-between;padding:0.5rem 0;border-bottom:1px solid #f0f0f0;font-size:0.85rem; }
    .tln-hours-row:last-child { border-bottom:none; }
    .tln-claim-box { background:#1a1a1a;border-radius:12px;padding:1.5rem;text-align:center; }
    .tln-claim-box h3 { color:#fff;border:none; }
    .tln-claim-box p { color:#ccc;font-size:0.9rem; }
    .tln-btn { display:inline-block;background:#e63946;color:#fff;padding:0.75rem 1.5rem;border-radius:6px;text-decoration:none;font-weight:700; }
    .tln-btn:hover { background:#d62839; }
    @media(max-width:700px) { .tln-main { grid-template-columns:1fr; } }
    </style>
    
    <div class="tln-profile">
        <div class="tln-hero">
            <div class="tln-hero-content">
                <h1>' . esc_html($biz) . '</h1>
                <p>Waxhaw, NC</p>
            </div>
        </div>
        
        <div class="tln-main">
            <div class="tln-left">
                <img src="https://thelocalnearbuy.com/wp-content/uploads/2026/05/support-local-businesses.webp" style="width:100%;border-radius:8px;">
                
                <div class="tln-card">
                    <h3>Hours</h3>
                    <div class="tln-hours-row"><span>Mon</span><span>Coming soon...</span></div>
                    <div class="tln-hours-row"><span>Tue</span><span>Coming soon...</span></div>
                    <div class="tln-hours-row"><span>Wed</span><span>Coming soon...</span></div>
                    <div class="tln-hours-row"><span>Thu</span><span>Coming soon...</span></div>
                    <div class="tln-hours-row"><span>Fri</span><span>Coming soon...</span></div>
                    <div class="tln-hours-row"><span>Sat</span><span>Coming soon...</span></div>
                    <div class="tln-hours-row"><span>Sun</span><span>Coming soon...</span></div>
                </div>
                
                <div class="tln-card">
                    <h3>Contact</h3>
                    <p class="tln-label">Phone</p>
                    <p class="tln-value">Coming soon...</p>
                    <p class="tln-label" style="margin-top:1rem;">Address</p>
                    <p class="tln-value">Coming soon...</p>
                </div>
            </div>
            
            <div class="tln-right">
                <div class="tln-card">
                    <h3>About</h3>
                    <p class="tln-value">Profile page loading from The Local NearBuy directory.</p>
                </div>
                
                <div class="tln-card">
                    <h3>What Neighbors Say</h3>
                    <p class="tln-value">No reviews yet. Be the first to leave a review!</p>
                </div>
                
                <div class="tln-claim-box">
                    <h3>Claim This Page</h3>
                    <p>Own this business? Claim your free page to update info, add photos, and more.</p>
                    <a href="/claim/" class="tln-btn">Claim Your Page</a>
                </div>
            </div>
        </div>
    </div>
    ';
    
    return $html;
}