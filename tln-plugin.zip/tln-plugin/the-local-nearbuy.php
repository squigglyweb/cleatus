<?php
/*
Plugin Name: TLN Plugin Bundle
Description: Business profiles, directory, and member features for The Local NearBuy
Version: 1.0.8 - Renamed shortcode to avoid conflict
Author: TLN
*/

define('TLN_PLUGIN_VERSION', '1.0.6');

// Load directory (which has API key)
require_once plugin_dir_path(__FILE__) . 'tln-directory.php';
require_once plugin_dir_path(__FILE__) . 'tln-claim.php';

// Profile shortcode - SIMPLE VERSION
function tln_business_profile_shortcode() {
    $biz = isset($_GET['biz']) ? $_GET['biz'] : '';
    $pid = isset($_GET['pid']) ? $_GET['pid'] : '';
    
    // Version marker
    $version = defined('TLN_PLUGIN_VERSION') ? TLN_PLUGIN_VERSION : 'unknown';
    
    if (empty($biz) && empty($pid)) {
        return '<!-- TLN v' . $version . ' --><div style="padding:2rem;background:#f0f0f0;border-radius:8px;"><h3>✅ TLN Profile Shortcode Working</h3><p>Add ?biz=Name&pid=PlaceID to URL.</p></div>';
    }
    
    if (empty($biz) || empty($pid)) {
        return '<p>Select a business from the <a href="/directory/">directory</a>.</p>';
    }
    
    // Fetch from Google Places API
    $api_key = defined('TLN_GOOGLE_API_KEY') ? TLN_GOOGLE_API_KEY : '';
    $business = array(
        'name' => $biz,
        'place_id' => $pid,
        'address' => '',
        'phone' => '',
        'website' => '',
        'rating' => '',
        'hours' => array(),
        'photos' => array(),
        'reviews' => array(),
    );
    
    // Call Google API if key is valid (not empty, not placeholder)
    if (!empty($api_key) && strlen($api_key) > 20 && $pid) {
        $url = 'https://maps.googleapis.com/maps/api/place/details/json?place_id=' . urlencode($pid) . '&fields=name,formatted_address,formatted_phone_number,opening_hours,website,rating,reviews,photos&key=' . $api_key;
        $response = wp_remote_get($url, array('timeout' => 10));
        if (!is_wp_error($response)) {
            $data = json_decode(wp_remote_retrieve_body($response), true);
            if (!empty($data['result'])) {
                $r = $data['result'];
                $business['name'] = $r['name'] ?? $biz;
                $business['address'] = $r['formatted_address'] ?? '';
                $business['phone'] = $r['formatted_phone_number'] ?? '';
                $business['website'] = $r['website'] ?? '';
                $business['rating'] = $r['rating'] ?? '';
                $business['hours'] = $r['opening_hours']['weekday_text'] ?? array();
                $business['photos'] = $r['photos'] ?? array();
                $business['reviews'] = $r['reviews'] ?? array();
            }
        }
    }
    
    // Make available to template
    global $tln_profile_business;
    $tln_profile_business = $business;
    
    // Include template
    ob_start();
    include plugin_dir_path(__FILE__) . 'templates/profile-free.php';
    return ob_get_clean();
}
add_shortcode('tln_business_profile_v107', 'tln_business_profile_shortcode');