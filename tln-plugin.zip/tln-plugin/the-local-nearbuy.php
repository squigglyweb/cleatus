<?php
/*
Plugin Name: TLN Plugin Bundle
Description: Business profiles, directory, and member features for The Local NearBuy
Version: 1.1.0 - Using template redirect
Author: TLN
*/

// Load directory (which has API key)
require_once plugin_dir_path(__FILE__) . 'tln-directory.php';
require_once plugin_dir_path(__FILE__) . 'tln-claim.php';

// Hook into template redirect
add_action('template_redirect', 'tln_profile_template_redirect');

function tln_profile_template_redirect() {
    global $wp;
    
    // Check if we're on the profile page
    if (!is_page('profile')) return;
    
    $biz = isset($_GET['biz']) ? $_GET['biz'] : '';
    $pid = isset($_GET['pid']) ? $_GET['pid'] : '';
    
    if (empty($biz) || empty($pid)) {
        // No params - show debug
        add_action('the_content', function($content) {
            return '<div style="padding:2rem;background:#d4edda;border-radius:8px;"><h3>✅ TLN v1.1.0 Working</h3><p>Add ?biz=Name&pid=PlaceID to URL.</p></div>';
        });
        return;
    }
    
    // We have params - load profile
    $api_key = defined('TLN_GOOGLE_API_KEY') ? TLN_GOOGLE_API_KEY : '';
    $business = array(
        'name' => $biz,
        'place_id' => $pid,
        'address' => '',
        'phone' => '',
        'website' => '',
        'rating' => '',
        'hours' => array(),
        'photos' => array(),
        'reviews' => array(),
    );
    
    // Call Google API if key is valid
    if (!empty($api_key) && strlen($api_key) > 20 && $pid) {
        $url = 'https://maps.googleapis.com/maps/api/place/details/json?place_id=' . urlencode($pid) . '&fields=name,formatted_address,formatted_phone_number,opening_hours,website,rating,reviews,photos&key=' . $api_key;
        $response = wp_remote_get($url, array('timeout' => 10));
        if (!is_wp_error($response)) {
            $data = json_decode(wp_remote_retrieve_body($response), true);
            if (!empty($data['result'])) {
                $r = $data['result'];
                $business['name'] = $r['name'] ?? $biz;
                $business['address'] = $r['formatted_address'] ?? '';
                $business['phone'] = $r['formatted_phone_number'] ?? '';
                $business['website'] = $r['website'] ?? '';
                $business['rating'] = $r['rating'] ?? '';
                $business['hours'] = $r['opening_hours']['weekday_text'] ?? array();
                $business['photos'] = $r['photos'] ?? array();
                $business['reviews'] = $r['reviews'] ?? array();
            }
        }
    }
    
    // Make available to template
    global $tln_profile_business;
    $tln_profile_business = $business;
    
    // Replace page content
    add_action('the_content', function($content) {
        global $tln_profile_business;
        ob_start();
        include plugin_dir_path(__FILE__) . 'templates/profile-free.php';
        return ob_get_clean();
    });
}