<?php
/*
Plugin Name: TLN Plugin Bundle
Description: Business profiles, directory, and member features for The Local NearBuy
Version: 2.2 - WITH GOOGLE API, CORRECT WAY
*/

// Load other TLN components
require_once plugin_dir_path(__FILE__) . 'tln-directory.php';
require_once plugin_dir_path(__FILE__) . 'tln-claim.php';

// Profile page handler
if (!is_admin()) {
    add_filter('the_content', 'tln_profile_content');
}

function tln_profile_content($content) {
    if (!is_page('profile')) {
        return $content;
    }
    
    $biz = isset($_GET['biz']) ? $_GET['biz'] : '';
    $pid = isset($_GET['pid']) ? $_GET['pid'] : '';
    
    if (empty($biz) || empty($pid)) {
        return '<div style="padding:2rem;background:#f0f0f0;border-radius:8px;"><h3>TLN Profile</h3><p>Add ?biz=Name&pid=PlaceID to URL.</p></div>';
    }
    
    // Default data
    $data = array(
        'name' => $biz,
        'address' => '',
        'phone' => '',
        'hours' => array(),
        'rating' => '',
        'website' => '',
        'photos' => array(),
        'reviews' => array()
    );
    
    // Fetch from Google API in the PLUGIN (not template)
    $api_key = defined('TLN_GOOGLE_API_KEY') ? TLN_GOOGLE_API_KEY : '';
    
    if (!empty($api_key) && strlen($api_key) > 20 && $pid) {
        $url = 'https://maps.googleapis.com/maps/api/place/details/json?place_id=' . urlencode($pid) . '&fields=name,formatted_address,formatted_phone_number,opening_hours,website,rating,reviews,photos&key=' . $api_key;
        $response = wp_remote_get($url, array('timeout' => 10));
        if (!is_wp_error($response)) {
            $json = json_decode(wp_remote_retrieve_body($response), true);
            if (!empty($json['result'])) {
                $r = $json['result'];
                $data['name'] = $r['name'] ?? $biz;
                $data['address'] = $r['formatted_address'] ?? '';
                $data['phone'] = $r['formatted_phone_number'] ?? '';
                $data['website'] = $r['website'] ?? '';
                $data['rating'] = $r['rating'] ?? '';
                $data['hours'] = $r['opening_hours']['weekday_text'] ?? array();
                $data['photos'] = $r['photos'] ?? array();
                $data['reviews'] = $r['reviews'] ?? array();
            }
        }
    }
    
    // Make data available to template
    global $tln_profile_business;
    $tln_profile_business = $data;
    
    // Include template
    ob_start();
    include plugin_dir_path(__FILE__) . 'templates/profile-free.php';
    return ob_get_clean();
}