<?php
/*
Plugin Name: TLN Plugin Bundle
Description: Business profiles, directory, and member features for The Local NearBuy
Version: 2.2 - WITH GOOGLE API
*/

// Load other TLN components
require_once plugin_dir_path(__FILE__) . 'tln-directory.php';
require_once plugin_dir_path(__FILE__) . 'tln-claim.php';

// Profile page handler
if (!is_admin()) {
    add_filter('the_content', 'tln_profile_content');
}

function tln_profile_content($content) {
    if (!is_page('profile')) {
        return $content;
    }
    
    $biz = isset($_GET['biz']) ? $_GET['biz'] : '';
    $pid = isset($_GET['pid']) ? $_GET['pid'] : '';
    
    if (empty($biz) || empty($pid)) {
        return '<div style="padding:2rem;background:#f0f0f0;border-radius:8px;"><h3>TLN Profile v2.2</h3><p>Add ?biz=Name&pid=PlaceID to URL.</p></div>';
    }
    
    // Default data
    $data = array(
        'name' => $biz,
        'address' => '',
        'phone' => '',
        'hours' => '',
        'rating' => '',
        'website' => ''
    );
    
    // Get API key
    $api_key = defined('TLN_GOOGLE_API_KEY') ? TLN_GOOGLE_API_KEY : '';
    
    // Fetch from Google if we have key
    if (!empty($api_key) && strlen($api_key) > 20 && $pid) {
        $url = 'https://maps.googleapis.com/maps/api/place/details/json?place_id=' . urlencode($pid) . '&fields=name,formatted_address,formatted_phone_number,opening_hours,website,rating&key=' . $api_key;
        $response = wp_remote_get($url, array('timeout' => 10));
        if (!is_wp_error($response)) {
            $json = json_decode(wp_remote_retrieve_body($response), true);
            if (!empty($json['result'])) {
                $r = $json['result'];
                $data['name'] = $r['name'] ?? $biz;
                $data['address'] = $r['formatted_address'] ?? '';
                $data['phone'] = $r['formatted_phone_number'] ?? '';
                $data['website'] = $r['website'] ?? '';
                $data['rating'] = $r['rating'] ?? '';
                $data['hours'] = !empty($r['opening_hours']['weekday_text']) ? implode('<br>', $r['opening_hours']['weekday_text']) : '';
            }
        }
    }
    
    // Build output
    $out = '<div style="padding:2rem;background:#fff;border-radius:8px;border:2px solid #e63946;max-width:600px;">';
    $out .= '<h2 style="color:#e63946;">' . esc_html($data['name']) . '</h2>';
    
    if ($data['address']) {
        $out .= '<p><strong>Address:</strong><br>' . esc_html($data['address']) . '</p>';
    }
    if ($data['phone']) {
        $out .= '<p><strong>Phone:</strong> <a href="tel:' . esc_attr($data['phone']) . '">' . esc_html($data['phone']) . '</a></p>';
    }
    if ($data['rating']) {
        $out .= '<p><strong>Rating:</strong> ' . esc_html($data['rating']) . ' ⭐</p>';
    }
    if ($data['hours']) {
        $out .= '<p><strong>Hours:</strong><br>' . $data['hours'] . '</p>';
    }
    if ($data['website']) {
        $out .= '<p><strong>Website:</strong> <a href="' . esc_url($data['website']) . '" target="_blank">' . esc_html($data['website']) . '</a></p>';
    }
    
    $out .= '</div>';
    return $out;
}