<?php
/*
Plugin Name: TLN Simple Profile
Description: Simple profile display - v2.0
Version: 2.0
*/

// Only run on front end
if (!is_admin()) {
    add_filter('the_content', 'tln_simple_profile_content', 1);
}

function tln_simple_profile_content($content) {
    // Only modify the profile page
    if (!is_page('profile')) {
        return $content;
    }
    
    // Get URL params
    $biz = isset($_GET['biz']) ? $_GET['biz'] : '';
    $pid = isset($_GET['pid']) ? $_GET['pid'] : '';
    
    // Simple test output
    return '<div style="padding:2rem;background:#d4edda;border-radius:8px;border:2px solid #28a745;">
        <h2>TLN v2.0 Working!</h2>
        <p>Business: ' . esc_html($biz) . '</p>
        <p>Place ID: ' . esc_html($pid) . '</p>
    </div>';
}