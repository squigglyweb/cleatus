<?php
/*
Plugin Name: TLN Plugin Bundle
Description: Business profiles, directory, and member features for The Local NearBuy
Version: 2.1
*/

// Load other TLN components
require_once plugin_dir_path(__FILE__) . 'tln-directory.php';
require_once plugin_dir_path(__FILE__) . 'tln-claim.php';

// Profile page handler - runs the_content filter
if (!is_admin()) {
    add_filter('the_content', 'tln_profile_content');
}

function tln_profile_content($content) {
    // Only on profile page
    if (!is_page('profile')) {
        return $content;
    }
    
    $biz = isset($_GET['biz']) ? $_GET['biz'] : '';
    $pid = isset($_GET['pid']) ? $_GET['pid'] : '';
    
    if (empty($biz) || empty($pid)) {
        return '<div style="padding:2rem;background:#f0f0f0;border-radius:8px;"><h3>TLN Profile v2.1</h3><p>Add ?biz=Name&pid=PlaceID to URL.</p></div>';
    }
    
    // Simple output (can upgrade later)
    return '<div style="padding:2rem;background:#fff;border-radius:8px;border:2px solid #e63946;">
        <h2>' . esc_html($biz) . '</h2>
        <p>Place ID: ' . esc_html($pid) . '</p>
        <p style="color:#666;">Profile loaded!</p>
    </div>';
}