<?php
/*
Plugin Name: TLN Plugin Bundle
Description: Business profiles, directory, and member features for The Local NearBuy
Version: 2.5 - HTML DIRECTLY IN PLUGIN
*/

// Load other TLN components
require_once plugin_dir_path(__FILE__) . 'tln-directory.php';
require_once plugin_dir_path(__FILE__) . 'tln-claim.php';

// Profile page handler
if (!is_admin()) {
    add_filter('the_content', 'tln_profile_content');
}

function tln_profile_content($content) {
    if (!is_page('profile')) {
        return $content;
    }
    
    $biz = isset($_GET['biz']) ? $_GET['biz'] : '';
    $pid = isset($_GET['pid']) ? $_GET['pid'] : '';
    
    if (empty($biz) || empty($pid)) {
        return '<div style="padding:2rem;background:#f0f0f0;border-radius:8px;"><h3>TLN Profile</h3><p>Add ?biz=Name&pid=PlaceID to URL.</p></div>';
    }
    
    // Build HTML directly - no template file includes
    $html = '
    <div style="max-width:800px;margin:0 auto;padding:2rem;background:#fff;border-radius:12px;border:2px solid #e63946;">
        <h1 style="color:#e63946;font-size:2rem;">' . esc_html($biz) . '</h1>
        <p style="color:#666;">Place ID: ' . esc_html($pid) . '</p>
        <hr style="margin:1.5rem 0;">
        <p><strong>Address:</strong> <span style="color:#666;">Coming soon...</span></p>
        <p><strong>Phone:</strong> <span style="color:#666;">Coming soon...</span></p>
        <p><strong>Hours:</strong> <span style="color:#666;">Coming soon...</span></p>
        <p><strong>Rating:</strong> <span style="color:#666;">Coming soon...</span></p>
    </div>
    ';
    
    return $html;
}