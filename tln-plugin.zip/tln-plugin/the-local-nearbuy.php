<?php
/*
Plugin Name: TLN Plugin Bundle
Description: Business profiles, directory, and member features for The Local NearBuy
Version: 1.0.0
Author: TLN
*/

// Load directory (which has API key)
require_once plugin_dir_path(__FILE__) . 'tln-directory.php';
require_once plugin_dir_path(__FILE__) . 'tln-claim.php';

// Profile shortcode - SIMPLE VERSION
function tln_business_profile_shortcode() {
    $biz = isset($_GET['biz']) ? $_GET['biz'] : '';
    $pid = isset($_GET['pid']) ? $_GET['pid'] : '';
    
    if (empty($biz) && empty($pid)) {
        return '<div style="padding:2rem;background:#f0f0f0;border-radius:8px;"><h3>✅ TLN Profile Shortcode Working</h3><p>Add ?biz=Name&pid=PlaceID to URL.</p></div>';
    }
    
    if (empty($biz) || empty($pid)) {
        return '<p>Select a business from the <a href="/directory/">directory</a>.</p>';
    }
    
    return '<div style="padding:2rem;background:#fff;border-radius:8px;">
        <h2>' . esc_html($biz) . '</h2>
        <p>Place ID: ' . esc_html($pid) . '</p>
        <p style="color:#666;">Profile template loading...</p>
    </div>';
}
add_shortcode('tln_business_profile', 'tln_business_profile_shortcode');